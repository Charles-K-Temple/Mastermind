﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grp2Mastermind
{   /*
    Josephine Domingo and Charles Karstens
    Group 2 Mastermind Project
    CIS3309: Spr 2017
    */

    class PlayerListClass
    {
        //class holds the list of players with their score

    }
}
