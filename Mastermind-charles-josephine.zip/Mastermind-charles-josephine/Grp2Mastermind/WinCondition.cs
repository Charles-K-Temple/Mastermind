﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grp2Mastermind
{   /*
    Josephine Domingo and Charles Karstens
    Group 2 Mastermind Project
    CIS3309: Spr 2017
    */

    class WinCondition
    {
        public static int Matches(int[] comp, int[] player)
        {   // checks the 2 arrays for matching values
            int match = 0;
            var listPlayer = new List<int> { 0, 1, 2, 3 };
            foreach (int c in comp)
            {
                foreach (int p in listPlayer)
                {
                    if (c == player[p])
                    {
                        match++;
                        listPlayer.Remove(p);
                        break;
                    }
                }
            }
            return match;
        }   // end Matches

        public static int InOrder(int[] comp, int[] player)
        {   // checks the 2 arrays for matching values in the same order
            int match = 0;           

            for (int i = 0; i < comp.Count(); i++)
            {
                    if (comp[i] == player[i])
                    {
                        match++;
                    }
            }
            return match;
        }   // return InOrder

        public static bool Winner(int[] comp, int[] player)
        {   // checks for win
            if (InOrder(comp, player) == comp.Length)
            {
                return true;
            }
            return false;
        }   // end Winner
    }
}