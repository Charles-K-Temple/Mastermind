﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Grp2Mastermind
{
    public partial class frmMasterMind : Form
    {
        // Seed the RNG.
        Random rng = new Random();

        int[] computerPix = new int[4];
        int[] playerPix = new int[4];
        int Level = 6;
        bool PossibleRepeats = true;

        // set global variables for color and set TryCount to zero
        int PointerColor = 0;
        int TryCount = 0;

        // set global variables for button placement
        int X_start = 240;
        int X_offset = 58;
        int Y_offset = 60;
        int Peg_offset = 24;

        public frmMasterMind()
        {
            InitializeComponent();
            this.Size = new Size(775, 820);
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            int SEED = rng.Next(13, 137);
            if (PossibleRepeats)
            {
                computerPix = RNGArray.GenerateNumbers(SEED, Level, 4);
            }
            else
            {
                computerPix = RNGArray.GenerateNonRepeatingNumbers(SEED, Level, 4);
            }
            string str = "";
            for (int i = 0; i < computerPix.Length; i++)
            {
                str += "  :  ";
                str += computerPix[i].ToString();
            }
            textBox1.Text = str;
            ShowSolution();
            var GuessLocation = this.btnGuess.Location;
            GenerateTryButtons(GuessLocation.X - X_start, GuessLocation.Y + Y_offset);
            btnGuess.Enabled = true;
            picGameBoard.SendToBack();
        }



        public void GenerateTryButtons(int X_Pos, int Y_Pos)
        {
            for (int x = 0; x < 4; x++)
            {
                CreateButton(X_Pos + X_offset * x, Y_Pos - Y_offset, "btn" + x + TryCount, Color.LightGray);
            }

        }

        public Button CreateButton(int xCoord, int yCoord, string name, Color color)
        {
            Button btn = new Button();
            btn.Location = new Point(xCoord, yCoord);
            btn.Show();
            btn.Name = name;

            btn.Size = new Size(35, 35);
            btn.BackColor = color;
            //event handler
            Controls.Add(btn);
            btn.Visible = true;
            btn.Click += new EventHandler(ColorGuessClick);
            return btn;
        }


        public void GeneratePegs(int xCoord, int yCoord)
        {   // generates the number and x-y placement values for 'Hint' pegs
            int y = TryCount - 1;
            int W = WinCondition.Matches(computerPix, playerPix);
            int BlackPegs = WinCondition.InOrder(computerPix, playerPix);
            int WhitePegs = W - BlackPegs;
            int Empty = 4 - (W);
            int i = 0;

            for (int b = 0; b < BlackPegs; b++)
            {
                CreatePegs(xCoord + Peg_offset * i, yCoord, "btnPeg" + i + TryCount, Color.Black);
                i++;
            }

            for (int w = 0; w < WhitePegs; w++)
            {
                CreatePegs(xCoord + Peg_offset * i, yCoord, "btnPeg" + i + TryCount, Color.White);
                i++;
            }

            for (int e = 0; e < Empty; e++)
            {
                CreatePegs(xCoord + Peg_offset * i, yCoord, "btnPeg" + i + TryCount, Color.SaddleBrown);
                i++;
            }
        }// end GeneratePegs

        public Button CreatePegs(int XCoord, int YCoord, string name, Color color)
        {   // creates the actual 'Hint' pegs
            Button btn = new Button();
            btn.Location = new Point(XCoord, YCoord);
            btn.Show();
            btn.Name = name;
            btn.Size = new Size(20, 20);
            btn.BackColor = color;
            btn.Visible = true;
            //btn.Enabled = false;            
            Controls.Add(btn);
            return btn;
        }// end CreatePegs

        private void btnColor_Click(object sender, EventArgs e)
        {   // event handler for Color Choices to transfer to 'Guess' pegs
            Button button = sender as Button;
            char i = button.Name[4];
            int c = Convert.ToInt32("" + i);
            PointerColor = c;
        }// end btnColor_Click

        private void ColorGuessClick(object sender, EventArgs e)
        {   // event handler to make 'Gues' pegs the chosen color from the 'palette'
            Button button = sender as Button;
            string colorX = ColorClass.color(PointerColor);

            button.Visible = true;
            button.BackColor = Color.FromName(colorX);
            //here you check which button was clicked by the sender
            char i = button.Name[3];
            int x = Convert.ToInt32("" + i);
            playerPix[x] = PointerColor;
        }// end ColorGuessClick

        private void ShowSolution()
        {   // shows the solution
            pic1.BackColor = Color.FromName(ColorClass.color(computerPix[0]));
            pic2.BackColor = Color.FromName(ColorClass.color(computerPix[1]));
            pic3.BackColor = Color.FromName(ColorClass.color(computerPix[2]));
            pic4.BackColor = Color.FromName(ColorClass.color(computerPix[3]));
        }   // end ShowSolution



        // validate the player name
        private void btnEnter_Click(object sender, EventArgs e)
        {
            List<PlayerClass> playerList = new List<PlayerClass>();
            string name = txtName.Text;

            if (name == "")
            {   // checks for and flags blank name
                MessageBox.Show("Please enter a valid name", "Error");
                txtName.Focus();
                txtName.Clear();
            }
            else
            {
                // creates new player object
                PlayerClass newPlayer = new PlayerClass();
                newPlayer.Name = name;
                lblName.Text = name;
                playerList.Add(newPlayer); // creates a new player object

                txtName.Visible = false;
                txtName.Enabled = false;
                lblEnterName.Visible = false;
                btnEnter.Visible = false;

                // enable the solution
                pic1.Enabled = true;
                pic2.Enabled = true;
                pic3.Enabled = true;
                pic4.Enabled = true;

                btnStart.Enabled = true;
                this.AcceptButton = btnStart;
                textBox1.Enabled = true;
            }
        }

        private void btnGuess_Click(object sender, EventArgs e)
        {
            DisableButtons();

            TryCount++;
            int M = WinCondition.Matches(computerPix, playerPix);
            int I = WinCondition.InOrder(computerPix, playerPix);
            bool W = WinCondition.Winner(computerPix, playerPix);
            MessageBox.Show("M: " + M + "  I: " + I + "  W:" + W);

            // test for win or loss
            if (WinCondition.Winner(computerPix, playerPix))
            {
                // yay winner or something
                // write to list/file playernanme & playerscore
                // disply list as leaderboard
                // GameOver();
            }
            else if (TryCount == 11)
            {
                // you're a big fat loser
                // GameOver();
            }

            var GuessLocation = this.btnGuess.Location;
            GenerateTryButtons(GuessLocation.X - X_start, GuessLocation.Y);
            GeneratePegs(GuessLocation.X, GuessLocation.Y);
            picGameBoard.SendToBack();
            btnGuess.Location = new Point(GuessLocation.X, GuessLocation.Y - Y_offset);
        }

        private void DisableButtons()
        {
            for (int x = 0; x < 4; x++)
            {
                string disable = "btn" + x + TryCount;
                Control[] cntrls = Controls.Find(disable, true);
                Control singleControl = cntrls[0];
                Button btn = (Button)singleControl;
                btn.Enabled = false;
            }
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            this.AcceptButton = btnEnter;
        }

        private void Easy()
        {
            btnC1.Visible = true;
            btnC2.Visible = true;
            btnC3.Visible = true;
            btnC4.Visible = true;
            btnC5.Visible = true;
            btnC6.Visible = true;
            btnC7.Visible = false;
            btnC8.Visible = false;

            btnC1.Enabled = true;
            btnC2.Enabled = true;
            btnC3.Enabled = true;
            btnC4.Enabled = true;
            btnC5.Enabled = true;
            btnC6.Enabled = true;

            Level = 6;
        }
        private void Medium()
        {
            Easy();
            btnC7.Visible = true;
            btnC7.Enabled = true;
            Level = 7;
        }
        private void Hard()
        {
            Medium();
            btnC8.Visible = true;
            btnC8.Enabled = true;
            Level = 8;
        }

        private void btnEasy_Click(object sender, EventArgs e)
        {
            Easy();
            lblLevel.Text = "Level: Easy";
        }

        private void btnMedium_Click(object sender, EventArgs e)
        {
            Medium();
            lblLevel.Text = "Level: Medium";
        }

        private void btnHard_Click(object sender, EventArgs e)
        {
            Hard();
            lblLevel.Text = "Level: Hard";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            PossibleRepeats = !PossibleRepeats;
        }
    }
}