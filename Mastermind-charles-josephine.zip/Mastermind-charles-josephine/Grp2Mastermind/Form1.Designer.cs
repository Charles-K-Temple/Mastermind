﻿namespace Grp2Mastermind
{
    partial class frmMasterMind
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMasterMind));
            this.btnStart = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.pic1 = new System.Windows.Forms.PictureBox();
            this.pic2 = new System.Windows.Forms.PictureBox();
            this.pic3 = new System.Windows.Forms.PictureBox();
            this.pic4 = new System.Windows.Forms.PictureBox();
            this.btnC1 = new System.Windows.Forms.Button();
            this.btnC2 = new System.Windows.Forms.Button();
            this.btnC3 = new System.Windows.Forms.Button();
            this.btnC4 = new System.Windows.Forms.Button();
            this.btnC5 = new System.Windows.Forms.Button();
            this.btnC6 = new System.Windows.Forms.Button();
            this.btnC7 = new System.Windows.Forms.Button();
            this.btnC8 = new System.Windows.Forms.Button();
            this.lblEnterName = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.btnEnter = new System.Windows.Forms.Button();
            this.btnGuess = new System.Windows.Forms.Button();
            this.picGameBoard = new System.Windows.Forms.PictureBox();
            this.lblName = new System.Windows.Forms.Label();
            this.btnEasy = new System.Windows.Forms.Button();
            this.btnMedium = new System.Windows.Forms.Button();
            this.btnHard = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.lblLevel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pic1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picGameBoard)).BeginInit();
            this.SuspendLayout();
            // 
            // btnStart
            // 
            this.btnStart.Enabled = false;
            this.btnStart.Location = new System.Drawing.Point(62, 180);
            this.btnStart.Margin = new System.Windows.Forms.Padding(2);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(157, 33);
            this.btnStart.TabIndex = 0;
            this.btnStart.Text = "Start New Game";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // textBox1
            // 
            this.textBox1.Enabled = false;
            this.textBox1.Location = new System.Drawing.Point(94, 294);
            this.textBox1.Margin = new System.Windows.Forms.Padding(2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(112, 22);
            this.textBox1.TabIndex = 1;
            // 
            // pic1
            // 
            this.pic1.BackColor = System.Drawing.Color.SaddleBrown;
            this.pic1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pic1.Enabled = false;
            this.pic1.Location = new System.Drawing.Point(315, 37);
            this.pic1.Margin = new System.Windows.Forms.Padding(4);
            this.pic1.Name = "pic1";
            this.pic1.Size = new System.Drawing.Size(37, 28);
            this.pic1.TabIndex = 4;
            this.pic1.TabStop = false;
            // 
            // pic2
            // 
            this.pic2.BackColor = System.Drawing.Color.SaddleBrown;
            this.pic2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pic2.Enabled = false;
            this.pic2.Location = new System.Drawing.Point(375, 37);
            this.pic2.Margin = new System.Windows.Forms.Padding(4);
            this.pic2.Name = "pic2";
            this.pic2.Size = new System.Drawing.Size(37, 28);
            this.pic2.TabIndex = 5;
            this.pic2.TabStop = false;
            // 
            // pic3
            // 
            this.pic3.BackColor = System.Drawing.Color.SaddleBrown;
            this.pic3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pic3.Enabled = false;
            this.pic3.Location = new System.Drawing.Point(435, 37);
            this.pic3.Margin = new System.Windows.Forms.Padding(4);
            this.pic3.Name = "pic3";
            this.pic3.Size = new System.Drawing.Size(37, 28);
            this.pic3.TabIndex = 6;
            this.pic3.TabStop = false;
            // 
            // pic4
            // 
            this.pic4.BackColor = System.Drawing.Color.SaddleBrown;
            this.pic4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pic4.Enabled = false;
            this.pic4.Location = new System.Drawing.Point(495, 37);
            this.pic4.Margin = new System.Windows.Forms.Padding(4);
            this.pic4.Name = "pic4";
            this.pic4.Size = new System.Drawing.Size(37, 28);
            this.pic4.TabIndex = 7;
            this.pic4.TabStop = false;
            // 
            // btnC1
            // 
            this.btnC1.BackColor = System.Drawing.Color.Red;
            this.btnC1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnC1.Enabled = false;
            this.btnC1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnC1.ForeColor = System.Drawing.Color.White;
            this.btnC1.Location = new System.Drawing.Point(77, 601);
            this.btnC1.Margin = new System.Windows.Forms.Padding(2);
            this.btnC1.Name = "btnC1";
            this.btnC1.Size = new System.Drawing.Size(76, 62);
            this.btnC1.TabIndex = 11;
            this.btnC1.Text = "Red";
            this.btnC1.UseVisualStyleBackColor = false;
            this.btnC1.Visible = false;
            this.btnC1.Click += new System.EventHandler(this.btnColor_Click);
            // 
            // btnC2
            // 
            this.btnC2.BackColor = System.Drawing.Color.Blue;
            this.btnC2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnC2.Enabled = false;
            this.btnC2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnC2.ForeColor = System.Drawing.Color.White;
            this.btnC2.Location = new System.Drawing.Point(163, 601);
            this.btnC2.Margin = new System.Windows.Forms.Padding(2);
            this.btnC2.Name = "btnC2";
            this.btnC2.Size = new System.Drawing.Size(76, 62);
            this.btnC2.TabIndex = 12;
            this.btnC2.Text = "Blue";
            this.btnC2.UseVisualStyleBackColor = false;
            this.btnC2.Visible = false;
            this.btnC2.Click += new System.EventHandler(this.btnColor_Click);
            // 
            // btnC3
            // 
            this.btnC3.BackColor = System.Drawing.Color.Green;
            this.btnC3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnC3.Enabled = false;
            this.btnC3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnC3.ForeColor = System.Drawing.Color.White;
            this.btnC3.Location = new System.Drawing.Point(77, 523);
            this.btnC3.Margin = new System.Windows.Forms.Padding(2);
            this.btnC3.Name = "btnC3";
            this.btnC3.Size = new System.Drawing.Size(76, 62);
            this.btnC3.TabIndex = 13;
            this.btnC3.Text = "Green";
            this.btnC3.UseVisualStyleBackColor = false;
            this.btnC3.Visible = false;
            this.btnC3.Click += new System.EventHandler(this.btnColor_Click);
            // 
            // btnC4
            // 
            this.btnC4.BackColor = System.Drawing.Color.Yellow;
            this.btnC4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnC4.Enabled = false;
            this.btnC4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnC4.ForeColor = System.Drawing.Color.Black;
            this.btnC4.Location = new System.Drawing.Point(163, 523);
            this.btnC4.Margin = new System.Windows.Forms.Padding(2);
            this.btnC4.Name = "btnC4";
            this.btnC4.Size = new System.Drawing.Size(76, 62);
            this.btnC4.TabIndex = 14;
            this.btnC4.Text = "Yellow";
            this.btnC4.UseVisualStyleBackColor = false;
            this.btnC4.Visible = false;
            this.btnC4.Click += new System.EventHandler(this.btnColor_Click);
            // 
            // btnC5
            // 
            this.btnC5.BackColor = System.Drawing.Color.White;
            this.btnC5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnC5.Enabled = false;
            this.btnC5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnC5.ForeColor = System.Drawing.Color.Black;
            this.btnC5.Location = new System.Drawing.Point(77, 448);
            this.btnC5.Margin = new System.Windows.Forms.Padding(2);
            this.btnC5.Name = "btnC5";
            this.btnC5.Size = new System.Drawing.Size(76, 62);
            this.btnC5.TabIndex = 15;
            this.btnC5.Text = "White";
            this.btnC5.UseVisualStyleBackColor = false;
            this.btnC5.Visible = false;
            this.btnC5.Click += new System.EventHandler(this.btnColor_Click);
            // 
            // btnC6
            // 
            this.btnC6.BackColor = System.Drawing.Color.Black;
            this.btnC6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnC6.Enabled = false;
            this.btnC6.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnC6.ForeColor = System.Drawing.Color.White;
            this.btnC6.Location = new System.Drawing.Point(163, 448);
            this.btnC6.Margin = new System.Windows.Forms.Padding(2);
            this.btnC6.Name = "btnC6";
            this.btnC6.Size = new System.Drawing.Size(76, 62);
            this.btnC6.TabIndex = 16;
            this.btnC6.Text = "Black";
            this.btnC6.UseVisualStyleBackColor = false;
            this.btnC6.Visible = false;
            this.btnC6.Click += new System.EventHandler(this.btnColor_Click);
            // 
            // btnC7
            // 
            this.btnC7.BackColor = System.Drawing.Color.Orange;
            this.btnC7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnC7.Enabled = false;
            this.btnC7.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnC7.ForeColor = System.Drawing.Color.Black;
            this.btnC7.Location = new System.Drawing.Point(77, 372);
            this.btnC7.Margin = new System.Windows.Forms.Padding(2);
            this.btnC7.Name = "btnC7";
            this.btnC7.Size = new System.Drawing.Size(76, 62);
            this.btnC7.TabIndex = 17;
            this.btnC7.Text = "Orange";
            this.btnC7.UseVisualStyleBackColor = false;
            this.btnC7.Visible = false;
            this.btnC7.Click += new System.EventHandler(this.btnColor_Click);
            // 
            // btnC8
            // 
            this.btnC8.BackColor = System.Drawing.Color.Violet;
            this.btnC8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnC8.Enabled = false;
            this.btnC8.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnC8.ForeColor = System.Drawing.Color.Black;
            this.btnC8.Location = new System.Drawing.Point(163, 372);
            this.btnC8.Margin = new System.Windows.Forms.Padding(2);
            this.btnC8.Name = "btnC8";
            this.btnC8.Size = new System.Drawing.Size(76, 62);
            this.btnC8.TabIndex = 18;
            this.btnC8.Text = "Violet";
            this.btnC8.UseVisualStyleBackColor = false;
            this.btnC8.Visible = false;
            this.btnC8.Click += new System.EventHandler(this.btnColor_Click);
            // 
            // lblEnterName
            // 
            this.lblEnterName.AutoSize = true;
            this.lblEnterName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEnterName.ForeColor = System.Drawing.Color.MintCream;
            this.lblEnterName.Location = new System.Drawing.Point(12, 9);
            this.lblEnterName.Name = "lblEnterName";
            this.lblEnterName.Size = new System.Drawing.Size(102, 18);
            this.lblEnterName.TabIndex = 19;
            this.lblEnterName.Text = "Enter Name:";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(15, 30);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(153, 22);
            this.txtName.TabIndex = 20;
            this.txtName.TextChanged += new System.EventHandler(this.txtName_TextChanged);
            // 
            // btnEnter
            // 
            this.btnEnter.Location = new System.Drawing.Point(174, 27);
            this.btnEnter.Name = "btnEnter";
            this.btnEnter.Size = new System.Drawing.Size(74, 29);
            this.btnEnter.TabIndex = 21;
            this.btnEnter.Text = "ENTER";
            this.btnEnter.UseVisualStyleBackColor = true;
            this.btnEnter.Click += new System.EventHandler(this.btnEnter_Click);
            // 
            // btnGuess
            // 
            this.btnGuess.Enabled = false;
            this.btnGuess.Location = new System.Drawing.Point(561, 633);
            this.btnGuess.Name = "btnGuess";
            this.btnGuess.Size = new System.Drawing.Size(94, 30);
            this.btnGuess.TabIndex = 22;
            this.btnGuess.Text = "Guess";
            this.btnGuess.UseVisualStyleBackColor = true;
            this.btnGuess.Click += new System.EventHandler(this.btnGuess_Click);
            // 
            // picGameBoard
            // 
            this.picGameBoard.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picGameBoard.BackgroundImage")));
            this.picGameBoard.Location = new System.Drawing.Point(266, 0);
            this.picGameBoard.Margin = new System.Windows.Forms.Padding(2);
            this.picGameBoard.Name = "picGameBoard";
            this.picGameBoard.Size = new System.Drawing.Size(600, 800);
            this.picGameBoard.TabIndex = 26;
            this.picGameBoard.TabStop = false;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.ForeColor = System.Drawing.Color.White;
            this.lblName.Location = new System.Drawing.Point(23, 226);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(65, 24);
            this.lblName.TabIndex = 27;
            this.lblName.Text = "Name";
            // 
            // btnEasy
            // 
            this.btnEasy.Location = new System.Drawing.Point(29, 144);
            this.btnEasy.Name = "btnEasy";
            this.btnEasy.Size = new System.Drawing.Size(65, 31);
            this.btnEasy.TabIndex = 28;
            this.btnEasy.Text = "Easy";
            this.btnEasy.UseVisualStyleBackColor = true;
            this.btnEasy.Click += new System.EventHandler(this.btnEasy_Click);
            // 
            // btnMedium
            // 
            this.btnMedium.Location = new System.Drawing.Point(100, 144);
            this.btnMedium.Name = "btnMedium";
            this.btnMedium.Size = new System.Drawing.Size(65, 31);
            this.btnMedium.TabIndex = 29;
            this.btnMedium.Text = "Medium";
            this.btnMedium.UseVisualStyleBackColor = true;
            this.btnMedium.Click += new System.EventHandler(this.btnMedium_Click);
            // 
            // btnHard
            // 
            this.btnHard.Location = new System.Drawing.Point(171, 144);
            this.btnHard.Name = "btnHard";
            this.btnHard.Size = new System.Drawing.Size(65, 31);
            this.btnHard.TabIndex = 30;
            this.btnHard.Text = "Hard";
            this.btnHard.UseVisualStyleBackColor = true;
            this.btnHard.Click += new System.EventHandler(this.btnHard_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.Red;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnExit.FlatAppearance.BorderSize = 3;
            this.btnExit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkRed;
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnExit.Location = new System.Drawing.Point(97, 693);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(122, 35);
            this.btnExit.TabIndex = 31;
            this.btnExit.Text = "E&XIT";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox1.ForeColor = System.Drawing.Color.White;
            this.checkBox1.Location = new System.Drawing.Point(30, 71);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(189, 22);
            this.checkBox1.TabIndex = 32;
            this.checkBox1.Text = "No Possible Repeats";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // lblLevel
            // 
            this.lblLevel.AutoSize = true;
            this.lblLevel.BackColor = System.Drawing.Color.Transparent;
            this.lblLevel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLevel.ForeColor = System.Drawing.Color.White;
            this.lblLevel.Location = new System.Drawing.Point(54, 257);
            this.lblLevel.Name = "lblLevel";
            this.lblLevel.Size = new System.Drawing.Size(60, 24);
            this.lblLevel.TabIndex = 33;
            this.lblLevel.Text = "Level";
            // 
            // frmMasterMind
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(120F, 120F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.DarkRed;
            this.CancelButton = this.btnExit;
            this.ClientSize = new System.Drawing.Size(757, 775);
            this.Controls.Add(this.lblLevel);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnHard);
            this.Controls.Add(this.btnMedium);
            this.Controls.Add(this.btnEasy);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.btnGuess);
            this.Controls.Add(this.btnEnter);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lblEnterName);
            this.Controls.Add(this.btnC8);
            this.Controls.Add(this.btnC7);
            this.Controls.Add(this.btnC6);
            this.Controls.Add(this.btnC5);
            this.Controls.Add(this.btnC4);
            this.Controls.Add(this.btnC3);
            this.Controls.Add(this.btnC2);
            this.Controls.Add(this.btnC1);
            this.Controls.Add(this.pic4);
            this.Controls.Add(this.pic3);
            this.Controls.Add(this.pic2);
            this.Controls.Add(this.pic1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.picGameBoard);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "frmMasterMind";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Master Mind";
            ((System.ComponentModel.ISupportInitialize)(this.pic1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picGameBoard)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.PictureBox pic1;
        private System.Windows.Forms.PictureBox pic2;
        private System.Windows.Forms.PictureBox pic3;
        private System.Windows.Forms.PictureBox pic4;
        private System.Windows.Forms.Button btnC1;
        private System.Windows.Forms.Button btnC2;
        private System.Windows.Forms.Button btnC3;
        private System.Windows.Forms.Button btnC4;
        private System.Windows.Forms.Button btnC5;
        private System.Windows.Forms.Button btnC6;
        private System.Windows.Forms.Button btnC7;
        private System.Windows.Forms.Button btnC8;
        private System.Windows.Forms.Label lblEnterName;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Button btnEnter;
        private System.Windows.Forms.Button btnGuess;
        private System.Windows.Forms.PictureBox picGameBoard;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Button btnEasy;
        private System.Windows.Forms.Button btnMedium;
        private System.Windows.Forms.Button btnHard;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label lblLevel;
    }
}