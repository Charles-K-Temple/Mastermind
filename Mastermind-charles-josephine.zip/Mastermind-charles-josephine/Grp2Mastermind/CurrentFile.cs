﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace Grp2Mastermind
{   /*
    Josephine Domingo and Charles Karstens
    Group 2 Mastermind Project
    CIS3309: Spr 2017
    */

    public class CurrentFile
    {
        private string currentFilePath;
        private StreamReader currentFileSR; //reference variable for StreamReader type
        private int recordReadCount;
        //create instance of StreamReader type and store reference value
        public CurrentFile(string filePath)
        {
            recordReadCount = 0;
            currentFilePath = filePath;

            try
            {
                currentFileSR = new StreamReader(currentFilePath);
            }

            catch (Exception ex)
            {
                MessageBox.Show("Cannot open file" + currentFilePath + "Terminate Program.", "Ouput File Connection Error.",
                                 MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }   // end currentFilePath


        public string getNextRecord(ref Boolean endOfFileFlag)
        {   //read record from file
            string nextRecord;
            endOfFileFlag = false;
            nextRecord = currentFileSR.ReadLine();

            if (nextRecord == null)
            {
                endOfFileFlag = true;
            }
            else
                recordReadCount += 1;

            return (nextRecord);
        }   // end getNextRecord

        public int getRecordReadCount()
        {   //get number of records read in file
            return recordReadCount;
        }   // end getRecordCount

        
        public void closeFile()
        {   //close input file
            currentFileSR.Close();
        }   // end closeFile
        
        public void rewindFile()
        {   //rewind input file
            recordReadCount = 0;
            currentFileSR.BaseStream.Seek(0, System.IO.SeekOrigin.Begin);
        }   // end rewindFile
    }
}

