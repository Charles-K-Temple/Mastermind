﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Grp2Mastermind
{   /*
    Josephine Domingo and Charles Karstens
    Group 2 Mastermind Project
    CIS3309: Spr 2017
    */

    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new frmMasterMind());
        }
    }
}
