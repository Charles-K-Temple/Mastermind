﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grp2Mastermind
{   /*
    Josephine Domingo and Charles Karstens
    Group 2 Mastermind Project
    CIS3309: Spr 2017
    */

    // class to return a string color value based on an int 1 thru 8
    class ColorClass
    {
        public static string color(int x)
        {
            string[] colors = { "blank", "Red", "Blue", "Green", "Yellow", "White", "Black", "Orange", "Violet" };
            return colors[x];
        }
    }
}